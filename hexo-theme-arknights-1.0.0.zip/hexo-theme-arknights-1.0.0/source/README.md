# 这是 gh-page 托管页
请切换到 master 分支查看 README.md

[Yue-plus / hexo-theme-arknights](https://github.com/Yue-plus/hexo-theme-arknights)

Hexo 重新部署后配置的域名失效可以修改 `<arknights>/source/CNAME` 文件。
